// Runs the packaged application on this computer, not an Arena preview server.
import { randomBytes } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const home = dirname(fileURLToPath(import.meta.url));
const store = join(home, 'local-data');
const loopback = '127.0.0.1';
let app, database, dbStarted = false, stopping = false;
// The package's own exit hook stops Postgres on Ctrl+C (persistent mode).
const stopApp = () => { stopping = true; if (app && app.exitCode === null && !app.killed) app.kill('SIGTERM'); };
process.on('SIGTERM', stopApp);
process.on('SIGINT', stopApp);
async function checkPort(port) {
  const s = createServer();
  await new Promise((ok, bad) => { s.once('error', bad); s.listen(port, loopback, ok); });
  const n = s.address().port;
  await new Promise((ok, bad) => s.close(e => e ? bad(e) : ok()));
  return n;
}
try {
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major < 22 || (major === 22 && minor < 12)) throw new Error('Use Node.js 22.12 or newer.');
  if (process.getuid?.() === 0) throw new Error('Run as a normal user, not root or sudo.');
  const arg = process.argv[2] ?? '--port=4100';
  if (!/^--port=\d+$/.test(arg)) throw new Error('Usage: npm start [-- --port=4101]');
  const port = Number(arg.slice(7));
  if (port < 1024 || port > 65535) throw new Error('Choose a port from 1024 to 65535.');
  try { await checkPort(port); } catch { throw new Error(`Port ${port} is unavailable. If this app is already running use that window; otherwise try npm start -- --port=4101`); }
  process.umask(0o077);
  await mkdir(store, { recursive: true, mode: 0o700 });
  const pgDir = join(store, 'postgres');
  const keyFile = join(store, '.database-key');
  const initialized = existsSync(join(pgDir, 'PG_VERSION'));
  if (!existsSync(keyFile)) {
    if (initialized) throw new Error('Existing database found without its local key. Restore local-data from your backup; nothing was reset.');
    await writeFile(keyFile, randomBytes(32).toString('hex'), { flag: 'wx', mode: 0o600 });
  }
  const secret = (await readFile(keyFile, 'utf8')).trim();
  if (!/^[a-f\d]{64}$/.test(secret)) throw new Error('The local database key is unreadable. Restore the local-data folder from a backup.');
  const { default: EmbeddedPostgres } = await import('embedded-postgres');
  const pgPort = await checkPort(0);
  database = new EmbeddedPostgres({
    databaseDir: pgDir, user: 'velocity', password: secret, port: pgPort,
    persistent: true, authMethod: 'scram-sha-256', initdbFlags: ['--encoding=UTF8'],
    postgresFlags: ['-c', 'listen_addresses=127.0.0.1', '-c', 'log_error_verbosity=terse', '-c', 'log_parameter_max_length=0', '-c', 'log_parameter_max_length_on_error=0'],
    onLog() {}, onError() { console.error('Local PostgreSQL reported a connection error.'); }
  });
  console.log(initialized ? 'Opening your local workspace…' : 'Preparing a new local workspace…');
  if (!initialized) await database.initialise();
  await database.start(); dbStarted = true;
  if (!stopping) {
    // Do not inherit provider credentials, SMTP settings or a DATABASE_URL from your shell.
    const sys = Object.fromEntries(Object.entries(process.env).filter(([key]) => /^(path|home|userprofile|systemroot|windir|comspec|tmpdir|temp|tmp|lang|lc_all|lc_messages|pathext|ld_library_path)$/i.test(key)));
    const origin = `http://${loopback}:${port}`;
    app = spawn(process.execPath, [join(home, 'dist', 'index.js')], {
      cwd: home, stdio: ['ignore', 'pipe', 'inherit'], windowsHide: true,
      env: { ...sys, NODE_ENV: 'production', HOST: loopback, PORT: String(port), APP_URL: origin,
        DATABASE_URL: `postgres://velocity:${secret}@${loopback}:${pgPort}/postgres`,
        MIGRATIONS_ON_STARTUP: 'true', ALLOW_SIGNUP: 'true', ASSISTANT_AI_ENABLED: 'false',
        INSIGHTS_PROVIDER: 'rules', FOUNDER_AUTH_EXPERIMENTAL: 'false', FOUNDER_MANAGEMENT_EXPERIMENTAL: 'false' }
    });
    const logs = createInterface({ input: app.stdout });
    logs.on('line', line => {
      let item; try { item = JSON.parse(line); } catch { return; }
      if (String(item.msg).startsWith('Solution Velocity listening')) {
        console.log(`\nOpen ${origin} in your browser.\nChoose Explore demo, or Start building to save your own work.\nKeep this window open. Press Ctrl+C to stop.\n`);
      } else if (item.level >= 50) console.error('The local application reported:', item.msg);
    });
    const code = await new Promise((ok, bad) => { app.once('error', bad); app.once('exit', ok); });
    if (!stopping && code !== 0) throw new Error('The local server stopped before a normal shutdown. Your data was kept.');
  }
} catch (err) {
  console.error('Could not start the local workspace:', err?.code === 'ERR_MODULE_NOT_FOUND' ? 'Run npm ci in this folder first.' : err?.message || 'Check that PostgreSQL is supported on your computer and that this folder is writable.');
  process.exitCode = 1;
} finally {
  // On a signal, embedded-postgres handles this itself; avoid requesting two shutdowns.
  if (dbStarted && !stopping) await database.stop();
}
